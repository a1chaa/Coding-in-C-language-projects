/*
CSC173
Aichata Doumbia adoumbi2@u.rochester.edu/   
31596312
PROJECT5

cd ~/5PROJECT173_ADOUMBI2
gcc -std=c11 -Wall -Werror -o circuit *.c

./circuit
*/



#ifndef GATES_H_
#define GATES_H_

#include "Boolean.h"

/**
 * A Gate has one or more Boolean inputs and a single Boolean output,
 * and can update its output based on the values of its inputs.
 */
typedef struct Gate* Gate;

// Constructors only for concrete types of Gates (see below)

/**
 * Free the given Gate, including its input and output Booleans.
 */
extern void free_Gate(Gate this);

/**
 * Allocate and return an new array of Gates of the given length.
 */
extern Gate* new_Gate_array(int len);

/**
 * Run the given Gate's update function to update the value of its output
 * based on the value(s) of its input(s).
 */
extern void Gate_update(Gate this);

/**
 * Print the given Gate, including the values of its input(s) and output.
 * Probably only useful for debugging.
 */
extern void Gate_dump(Gate this);

/**
 * Return the number of inputs for the given Gate.
 */
extern int Gate_numInputs(Gate this);

 /**
 * Return the index'th input of the given Gate.
 */
extern Boolean Gate_getInput(Gate this, int index);

/**
 * Return the output of the given Gate.
 */
extern Boolean Gate_getOutput(Gate this);

//
// Concrete gate types implemented by this package:
//

/**
 * Return a new unary NOT Gate (an interverter).
 */
extern Gate new_Inverter(void);

/**
 * Return a new binary AND Gate.
 */
extern Gate new_AndGate(void);

/**
 * Return a new binary OR Gate.
 */
extern Gate new_OrGate(void);

/**
 * Return a new 3-input AND Gate.
 */
extern Gate new_And3Gate(void);

/**
 * Return a new 4-input OR Gate.
 */
extern Gate new_Or4Gate(void);


/**
 * Return a new NOR gate
 */
extern Gate new_NORGate(void);

/**
 * Return a new NAND gate
 */
extern Gate new_NANDGate(void);

#endif /* GATES_H_ */
