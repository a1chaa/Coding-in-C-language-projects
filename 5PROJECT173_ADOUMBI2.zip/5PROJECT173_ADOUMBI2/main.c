/*
CSC173
Aichata Doumbia adoumbi2@u.rochester.edu/   
31596312
PROJECT5

cd ~/5PROJECT173_ADOUMBI2
gcc -std=c11 -Wall -Werror -o circuit *.c

./circuit
*/




#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include "Circuit.h"

// ------------------- Circuit A -------------------
Circuit circuitA(void) {
    char* title = "This is circuit A";

    int NINPUTS = 2;
    Boolean x = new_Boolean(false);
    Boolean y = new_Boolean(false);
    Boolean* inputs = new_Boolean_array(NINPUTS);
    inputs[0] = x;
    inputs[1] = y;

    int NOUTPUTS = 1;
    Boolean result = new_Boolean(false);
    Boolean* outputs = new_Boolean_array(NOUTPUTS);
    outputs[0] = result;

    int NGATES = 3;
    Gate OR1 = new_OrGate();
    Gate AND1 = new_AndGate();
    Gate OR2 = new_OrGate();
    Gate* gates = new_Gate_array(NGATES);
    gates[0] = OR1;
    gates[1] = AND1;
    gates[2] = OR2;

    Circuit circuit = new_Circuit(title, NINPUTS, inputs, NOUTPUTS, outputs, NGATES, gates);

    Circuit_connect(circuit, x, Gate_getInput(OR1, 0));
    Circuit_connect(circuit, y, Gate_getInput(OR1, 1));
    Boolean x_OR_y = Gate_getOutput(OR1);

    Circuit_connect(circuit, x, Gate_getInput(AND1, 0));
    Circuit_connect(circuit, y, Gate_getInput(AND1, 1));
    Boolean x_AND_y = Gate_getOutput(AND1);

    Circuit_connect(circuit, x_OR_y, Gate_getInput(OR2, 0));
    Circuit_connect(circuit, x_AND_y, Gate_getInput(OR2, 1));
    Circuit_connect(circuit, Gate_getOutput(OR2), result);

    return circuit;
}

// ------------------- Circuit B -------------------
Circuit circuitB(void) {
    char* title = "This is circuit B";

    int NINPUTS = 3;
    Boolean x = new_Boolean(false);
    Boolean y = new_Boolean(false);
    Boolean z = new_Boolean(false);
    Boolean* inputs = new_Boolean_array(NINPUTS);
    inputs[0] = x;
    inputs[1] = y;
    inputs[2] = z;

    int NOUTPUTS = 1;
    Boolean result = new_Boolean(false);
    Boolean* outputs = new_Boolean_array(NOUTPUTS);
    outputs[0] = result;

    int NGATES = 4;
    Gate NOT_x = new_Inverter();
    Gate AND1 = new_AndGate();
    Gate OR1 = new_OrGate();
    Gate AND2 = new_AndGate();

    Gate* gates = new_Gate_array(NGATES);
    gates[0] = NOT_x;
    gates[1] = AND1;
    gates[2] = OR1;
    gates[3] = AND2;

    Circuit circuit = new_Circuit(title, NINPUTS, inputs, NOUTPUTS, outputs, NGATES, gates);

    Circuit_connect(circuit, x, Gate_getInput(NOT_x, 0));
    Boolean nx = Gate_getOutput(NOT_x);

    Circuit_connect(circuit, nx, Gate_getInput(AND1, 0));
    Circuit_connect(circuit, y, Gate_getInput(AND1, 1));
    Boolean left = Gate_getOutput(AND1);

    Circuit_connect(circuit, y, Gate_getInput(OR1, 0));
    Circuit_connect(circuit, z, Gate_getInput(OR1, 1));
    Boolean right = Gate_getOutput(OR1);

    Circuit_connect(circuit, left, Gate_getInput(AND2, 0));
    Circuit_connect(circuit, right, Gate_getInput(AND2, 1));
    Circuit_connect(circuit, Gate_getOutput(AND2), result);

    return circuit;
}

// ------------------- Circuit C -------------------
Circuit circuitC(void) {
    char* title = "This is circuit C";

    int NINPUTS = 3;
    Boolean x = new_Boolean(false);
    Boolean y = new_Boolean(false);
    Boolean z = new_Boolean(false);
    Boolean* inputs = new_Boolean_array(NINPUTS);
    inputs[0] = x;
    inputs[1] = y;
    inputs[2] = z;

    int NOUTPUTS = 1;
    Boolean result = new_Boolean(false);
    Boolean* outputs = new_Boolean_array(NOUTPUTS);
    outputs[0] = result;

    int NGATES = 6;
    Gate NOT_x = new_Inverter();
    Gate NOT_z = new_Inverter();
    Gate AND1 = new_AndGate();
    Gate AND2 = new_AndGate();
    Gate NOT_right = new_Inverter();
    Gate OR1 = new_OrGate();

    Gate* gates = new_Gate_array(NGATES);
    gates[0] = NOT_x;
    gates[1] = NOT_z;
    gates[2] = AND1;
    gates[3] = AND2;
    gates[4] = NOT_right;
    gates[5] = OR1;

    Circuit circuit = new_Circuit(title, NINPUTS, inputs, NOUTPUTS, outputs, NGATES, gates);

    Circuit_connect(circuit, x, Gate_getInput(NOT_x, 0));
    Boolean nx = Gate_getOutput(NOT_x);

    Circuit_connect(circuit, z, Gate_getInput(NOT_z, 0));
    Boolean nz = Gate_getOutput(NOT_z);

    Circuit_connect(circuit, nx, Gate_getInput(AND1, 0));
    Circuit_connect(circuit, y, Gate_getInput(AND1, 1));
    Boolean left = Gate_getOutput(AND1);

    Circuit_connect(circuit, nz, Gate_getInput(AND2, 0));
    Circuit_connect(circuit, y, Gate_getInput(AND2, 1));
    Boolean inner_right = Gate_getOutput(AND2);

    Circuit_connect(circuit, inner_right, Gate_getInput(NOT_right, 0));
    Boolean right = Gate_getOutput(NOT_right);

    Circuit_connect(circuit, left, Gate_getInput(OR1, 0));
    Circuit_connect(circuit, right, Gate_getInput(OR1, 1));
    Circuit_connect(circuit, Gate_getOutput(OR1), result);

    return circuit;
}

// ------------------- Output Helper -------------------
void testAllCombo(Circuit circuit, char** inputNames, char** outputNames) {
    int NINPUTS = Circuit_numInputs(circuit);
    int NOUTPUTS = Circuit_numOutputs(circuit);
    int NCOMBO = 1 << NINPUTS;

    for (int i = 0; i < NINPUTS; i++) {
        printf("%s ", inputNames[i]);
    }
    printf("| ");
    for (int i = 0; i < NOUTPUTS; i++) {
        printf("%s ", outputNames[i]);
    }
    printf("\n");

    for (int combo = 0; combo < NCOMBO; combo++) {
        for (int i = 0; i < NINPUTS; i++) {
            bool bit = (combo >> (NINPUTS - 1 - i)) & 1;
            Circuit_setInput(circuit, i, bit);
        }

        Circuit_update(circuit);

        for (int i = 0; i < NINPUTS; i++) {
            printf("%d ", Boolean_getValue(Circuit_getInput(circuit, i)) ? 1 : 0);
        }

        printf("| ");

        for (int i = 0; i < NOUTPUTS; i++) {
            printf("%d ", Boolean_getValue(Circuit_getOutput(circuit, i)) ? 1 : 0);
        }

        printf("\n");
    }
}

// ------------------- Name Helpers -------------------
char** getStandardInputNames(int count) {
    static char* two[] = {"x", "y"};
    static char* three[] = {"x", "y", "z"};
    if (count == 2) return two;
    if (count == 3) return three;
    return NULL;
}

char** generateSingleOutputName(const char* name) {
    char** names = malloc(sizeof(char*));
    names[0] = malloc(16);
    snprintf(names[0], 16, "%s", name);
    return names;
}

// ------------------- Extra Credit Circuit FG -------------------
Circuit circuitFG(void) {
    char* title = "Extra credit Circuit";

    int NINPUTS = 3;
    Boolean a = new_Boolean(false);
    Boolean b = new_Boolean(false);
    Boolean c = new_Boolean(false);
    Boolean* inputs = new_Boolean_array(NINPUTS);
    inputs[0] = a;
    inputs[1] = b;
    inputs[2] = c;

    int NOUTPUTS = 2;
    Boolean f = new_Boolean(false);
    Boolean g = new_Boolean(false);
    Boolean* outputs = new_Boolean_array(NOUTPUTS);
    outputs[0] = f;
    outputs[1] = g;

    int NGATES = 11;
    Gate NOT_a = new_Inverter();
    Gate NOT_b = new_Inverter();
    Gate NOT_c = new_Inverter();
    Gate AND1 = new_And3Gate();  // ✅ corrected
    Gate AND2 = new_And3Gate();  // ✅ corrected
    Gate AND3 = new_And3Gate();  // ✅ corrected
    Gate OR1 = new_OrGate();
    Gate OR2 = new_OrGate();
    Gate AND4 = new_And3Gate();  // ✅ corrected
    Gate AND5 = new_And3Gate();  // ✅ corrected
    Gate OR3 = new_OrGate();

    Gate* gates = new_Gate_array(NGATES);
    gates[0] = NOT_a;
    gates[1] = NOT_b;
    gates[2] = NOT_c;
    gates[3] = AND1;
    gates[4] = AND2;
    gates[5] = AND3;
    gates[6] = OR1;
    gates[7] = OR2;
    gates[8] = AND4;
    gates[9] = AND5;
    gates[10] = OR3;

    Circuit circuit = new_Circuit(title, NINPUTS, inputs, NOUTPUTS, outputs, NGATES, gates);

    Circuit_connect(circuit, a, Gate_getInput(NOT_a, 0));
    Boolean na = Gate_getOutput(NOT_a);
    Circuit_connect(circuit, b, Gate_getInput(NOT_b, 0));
    Boolean nb = Gate_getOutput(NOT_b);
    Circuit_connect(circuit, c, Gate_getInput(NOT_c, 0));
    Boolean nc = Gate_getOutput(NOT_c);

    Circuit_connect(circuit, na, Gate_getInput(AND1, 0));
    Circuit_connect(circuit, nb, Gate_getInput(AND1, 1));
    Circuit_connect(circuit, nc, Gate_getInput(AND1, 2));
    Boolean f1 = Gate_getOutput(AND1);

    Circuit_connect(circuit, na, Gate_getInput(AND2, 0));
    Circuit_connect(circuit, b, Gate_getInput(AND2, 1));
    Circuit_connect(circuit, nc, Gate_getInput(AND2, 2));
    Boolean f2 = Gate_getOutput(AND2);

    Circuit_connect(circuit, na, Gate_getInput(AND3, 0));
    Circuit_connect(circuit, b, Gate_getInput(AND3, 1));
    Circuit_connect(circuit, c, Gate_getInput(AND3, 2));
    Boolean f3 = Gate_getOutput(AND3);

    Circuit_connect(circuit, f1, Gate_getInput(OR1, 0));
    Circuit_connect(circuit, f2, Gate_getInput(OR1, 1));
    Boolean partial_f = Gate_getOutput(OR1);

    Circuit_connect(circuit, partial_f, Gate_getInput(OR2, 0));
    Circuit_connect(circuit, f3, Gate_getInput(OR2, 1));
    Circuit_connect(circuit, Gate_getOutput(OR2), f);

    Circuit_connect(circuit, na, Gate_getInput(AND4, 0));
    Circuit_connect(circuit, nb, Gate_getInput(AND4, 1));
    Circuit_connect(circuit, nc, Gate_getInput(AND4, 2));
    Boolean g1 = Gate_getOutput(AND4);

    Circuit_connect(circuit, na, Gate_getInput(AND5, 0));
    Circuit_connect(circuit, nb, Gate_getInput(AND5, 1));
    Circuit_connect(circuit, c, Gate_getInput(AND5, 2));
    Boolean g2 = Gate_getOutput(AND5);

    Circuit_connect(circuit, g1, Gate_getInput(OR3, 0));
    Circuit_connect(circuit, g2, Gate_getInput(OR3, 1));
    Circuit_connect(circuit, Gate_getOutput(OR3), g);

    return circuit;
}

// ------------------- Main -------------------
int main(void) {
    Circuit a = circuitA();
    Circuit b = circuitB();
    Circuit c = circuitC();
    Circuit fg = circuitFG();

    char* fgInputNames[] = {"a", "b", "c"};
    char* fgOutputNames[] = {"f", "g"};

    printf("Circuit A:\n");
    testAllCombo(a, getStandardInputNames(2), generateSingleOutputName("result"));
    printf("\n");

    printf("Circuit B:\n");
    testAllCombo(b, getStandardInputNames(3), generateSingleOutputName("result"));
    printf("\n");

    printf("Circuit C:\n");
    testAllCombo(c, getStandardInputNames(3), generateSingleOutputName("result"));
    printf("\n");

    printf("Extra credit Circuit:\n");
    testAllCombo(fg, fgInputNames, fgOutputNames);

    free_Circuit(a);
    free_Circuit(b);
    free_Circuit(c);
    free_Circuit(fg);

    return 0;
}
