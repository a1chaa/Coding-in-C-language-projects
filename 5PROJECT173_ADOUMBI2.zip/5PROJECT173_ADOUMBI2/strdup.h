/*
 * File: strdup.h
 * Creator: George Ferguson
 * Created: Tue Nov 29 14:48:33 2022
 */

#ifndef _strdup_h_gf
#define _strdup_h_gf

extern char *STRDUP(const char *s);

#endif
