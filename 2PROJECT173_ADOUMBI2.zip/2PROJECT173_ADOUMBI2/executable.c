/*
CSC173
Aichata Doumbia adoumbi2@u.rochester.edu/   
31596312
PROJECT2

cd /Users/aichadoumbia/2PROJECT173_ADOUMBI2

gcc -std=c99 -Wall -Werror -o executable executable.c


test:
-1
-3*+4
1--1

GRAMMAR FOR A LANGUAGE:
E →T U
U → + E | - E | empty
T → F G
G → * T | / T | empty
F → + F | - F | A
A → ( E ) | N
N → D M
M → N | empty
D → 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9



*/

#include <stdlib.h>     // library functions (malloc, free)
#include <stdbool.h>    // Boolean type 
#include <stdio.h>      // I/O functions (printf, scanf)
#include <string.h>     // String handling functions (strcpy, strcmp)
#include <ctype.h>      // Character type functions (isdigit, isspace)

#define FAILED NULL     // Define FAILED as NULL to represent a failed parse

// Constants for maximum sizes
#define MAX_STACK_SIZE 1000        // Max size of the stack used in parsing
#define MAX_SYMBOL_SIZE 10         // Max length of a symbol (terminals/non-terminals)
#define MAX_PRODUCTIONS 50         // Max # of grammar productions
#define MAX_SYMBOLS 50             // Max # of symbols (terminals/non-terminals)

// Struct to represent a parse tree node
typedef struct NODE *TREE;
struct NODE {
    char *label;            // Label of the node (the grammar symbol)
    TREE leftmostChild;     // Pointer to the leftmost child node
    TREE rightSibling;      // Pointer to the right sibling node
};

// Structure to represent grammar productions
typedef struct {
    char lhs[MAX_SYMBOL_SIZE];                   // Left-hand side of the production
    char rhs[MAX_SYMBOL_SIZE][MAX_SYMBOL_SIZE];  // Right-hand side symbols
    int rhsCount;                                // # of symbols on the right-hand side
} Production;

// Structure for the parsing table
typedef struct {
    char nonTerminals[MAX_SYMBOLS][MAX_SYMBOL_SIZE]; // [][] of non-terminals
    char terminals[MAX_SYMBOLS][MAX_SYMBOL_SIZE];    // Array of terminals
    int parsingTable[MAX_SYMBOLS][MAX_SYMBOLS];      // Parsing table entries
    int numNonTerminals;   // Number of non-terminals
    int numTerminals;      // Number of terminals
} ParsingTable;

// Functions for CREATING parse tree nodes
TREE node0(const char *x);                   // a node with no children
TREE node1(const char *x, TREE t);          // a node with one child
TREE node2(const char *x, TREE t1, TREE t2); // a node with two children

// Function for PRINTING the parse tree
void printTree(TREE root);                     // Print the parse tree
void printTreeHelper(TREE root, int indent);   // Helper function for printing with indentation

// Input handling variables
char *nextTerm;   // Pointer to the next input character
TREE parseTree;   // Pointer to the root of the parse tree

// Functions for parsing table management
int getNonTerminalIndex(ParsingTable *pt, char *nonTerminal);  // Get index of a non-terminal
int getTerminalIndex(ParsingTable *pt, char *terminal);        // Get index of a terminal
ParsingTable *createParsingTable(Production productions[], int numProductions); // Create parsing table
void populateTable(ParsingTable *pt);                       // Populate the parsing table with entries
void printParsingTable(ParsingTable *pt);                   // Printing table.

// Stack structure for table-driven parser
typedef struct {
    char symbols[MAX_STACK_SIZE][MAX_SYMBOL_SIZE]; // Stack to store grammar symbols
    TREE nodes[MAX_STACK_SIZE];                    // Stack to store parse tree nodes
    int top;                                       // Index of the top of the stack
} Stack;

// strdup implementation to duplicate a string
char *STRDUP(const char *s) {
    char *d = malloc(strlen(s) + 1);  // Allocate memory for the new string.
    if (d) {
        strcpy(d, s);                 // Copy the original string into the new memory
    }
    return d;                         // Return the duplicated string
}

// Skip any whitespace characters in the input
void skipWhitespace() {
    while (isspace(*nextTerm)) {      // Skip spaces, tabs, and newlines
        nextTerm++;                   // Move to the next input character
    }
}

// Check if the current input character matches the given character
bool lookahead(char c) {
    skipWhitespace();                 // Skip leading spaces before checking
    return *nextTerm == c;            // Check if the current input matches 'c'
}

// Match the current input character to the given character and advance if successful
bool match(char c) {
    if (lookahead(c)) {               // If current input matches 'c'
        nextTerm++;                   // Move to the next input character
        return true;                  // Return true for successful match
    } else {
        return false;                 // Return false for unsuccessful match
    }
}

// Check if the next nonwhitespace character is a digit
bool isNextDigit() {
    skipWhitespace();                 // Skip leading spaces before checking
    return isdigit(*nextTerm);        // Return true if the next character is a digit
}

// Functions for recursive descent parsing of non-terminals.
TREE E();    // Parse non-terminal E
TREE U();    // Parse non-terminal U
TREE T();    // Parse non-terminal T
TREE G();    // Parse non-terminal G
TREE F();    // Parse non-terminal F
TREE A();    // Parse non-terminal A
TREE N();    // Parse non-terminal N
TREE M();    // Parse non-terminal M
TREE D();    // Parse non-terminal D

// Recursive-descent parser function for non-terminal E (E -> T U)
TREE E() {
    skipWhitespace();                 // Skip leading spaces
    TREE t = T();                     // Parse T
    if (t == FAILED) return FAILED;   // Return FAILED if T parsing failed
    TREE u = U();                     // Parse U
    if (u == FAILED) return FAILED;   // Return FAILED if U parsing failed
    t->rightSibling = u;              // Link siblings explicitly (T and U)
    return node1("E", t);             // Return node E with T and U as children
}

// Recursive-descent parser function for non-terminal U (U -> + E | - E | e)
TREE U() {
    skipWhitespace();                 // Skip leading spaces
    if (lookahead('+')) {             // If next input is '+'
        match('+');                   // Consume the '+'
        TREE e = E();                 // Parse E
        if (e == FAILED) return FAILED;
        return node2("U", node0("+"), e); // U -> + E
    } else if (lookahead('-')) {      // If next input is '-'
        match('-');                   // Consume the '-'
        TREE e = E();                 // Parse E
        if (e == FAILED) return FAILED;
        return node2("U", node0("-"), e); // U -> - E
    } else {
        return node1("U", node0("e"));    // U -> e (epsilon), return node with epsilon
    }
}

// Recursive-descent parser function for non-terminal T (T -> F G)
TREE T() {
    skipWhitespace();                 // Skip leading spaces
    TREE f = F();                     // Parse F
    if (f == FAILED) return FAILED;   // Return FAILED if F parsing failed
    TREE g = G();                     // Parse G
    if (g == FAILED) return FAILED;   // Return FAILED if G parsing failed
    f->rightSibling = g;              // Link siblings explicitly (F and G)
    return node1("T", f);             // Return node T with F and G as children
}

// Recursive-descent parser function for non-terminal G (G -> * T | / T | e)
TREE G() {
    skipWhitespace();                 // Skip leading spaces
    if (lookahead('*')) {             // If next input is '*'
        match('*');                   // Consume the '*'
        TREE t = T();                 // Parse T
        if (t == FAILED) return FAILED;
        return node2("G", node0("*"), t); // G -> * T
    } else if (lookahead('/')) {      // If next input is '/'
        match('/');
        TREE t = T();                 // Parse T
        if (t == FAILED) return FAILED;
        return node2("G", node0("/"), t); // G -> / T
    } else {
        return node1("G", node0("e"));    // G -> e (epsilon), return node with epsilon
    }
}

// Recursive-descent parser function for non-terminal F (F -> + F | - F | A)
TREE F() {
    skipWhitespace();                 // Skip leading spaces
    if (lookahead('+')) {             // If next input is '+'
        match('+');
        TREE f = F();                 // Parse F recursively
        if (f == FAILED) return FAILED;
        return node2("F", node0("+"), f); // F -> + F
    } else if (lookahead('-')) {      // If next input is '-'
        match('-');
        TREE f = F();                 // Parse F recursively
        if (f == FAILED) return FAILED;
        return node2("F", node0("-"), f); // F -> - F
    } else {
        TREE a = A();                 // Parse A
        if (a == FAILED) return FAILED;
        return node1("F", a);          // F -> A
    }
}

// Recursive-descent parser function for non-terminal A (A -> ( E ) | N)
TREE A() {
    skipWhitespace();                 // Skip leading spaces
    if (lookahead('(')) {             // If next input is '('
        match('(');                   // Consume '('
        TREE e = E();                 // Parse E
        if (e == FAILED) return FAILED;
        if (!match(')')) return FAILED; // Expect ')'
        // Create nodes for '(', E, and ')'
        TREE leftParen = node0("(");
        TREE rightParen = node0(")");
        leftParen->rightSibling = e;  // Link '(' to E
        e->rightSibling = rightParen; // Link E to ')'
        return node1("A", leftParen); // Return node A with '(' as the first child
    } else {
        TREE n = N();                 // Parse N
        if (n == FAILED) return FAILED;
        return node1("A", n);          // A -> N
    }
}

// Recursive-descent parser function for non-terminal N (N -> D M)
TREE N() {
    skipWhitespace();                 // Skip leading spaces
    TREE d = D();                     // Parse D
    if (d == FAILED) return FAILED;
    TREE m = M();                     // Parse M
    if (m == FAILED) return FAILED;
    d->rightSibling = m;              // Link siblings explicitly (D and M)
    return node1("N", d);             // Return node N with D and M as children
}

// Recursive-descent parser function for non-terminal M (M -> N | e)
TREE M() {
    skipWhitespace();                 // Skip leading spaces
    if (isNextDigit()) {              // If the next input is a digit
        TREE n = N();                 // Parse N recursively
        if (n == FAILED) return FAILED;
        return node1("M", n);          // M -> N
    } else {
        return node1("M", node0("e"));    // M -> e (epsilon), return node with epsilon
    }
}

// Recursive-descent parser function for non-terminal D (D -> 0 | 1 | ... | 9)
TREE D() {
    skipWhitespace();                 // Skip leading spaces
    if (isNextDigit()) {              // If the next input is a digit
        char digit = *nextTerm;        // Store the digit character
        match(digit);                  // Consume the digit
        char str[2] = {digit, '\0'};   // Create string representation of the digit
        return node1("D", node0(str)); // Return node D with the digit as its child
    } else {
        return FAILED;                // Return FAILED if not a digit
    }
}

// Function to print the parse tree in an indented format
void printTree(TREE root) {
    printTreeHelper(root, 0);         // Start printing from the root with an indent of 0
}

// Recursive helper function to print the parse tree with indentation
void printTreeHelper(TREE root, int indent) {
    if (root == NULL) return;         // Base case: if the node is NULL, do nothing

    for (int i = 0; i < indent; i++) {
        printf("  ");                 // Print indentation spaces based on the level of depth
    }
    printf("%s\n", root->label);      // Print the label of the current node

    // Recursively print the leftmost child with increased indentation
    printTreeHelper(root->leftmostChild, indent + 1);

    // Print the right siblings at the same indentation level
    printTreeHelper(root->rightSibling, indent);
}

// Function to create a parse tree node with no children
TREE node0(const char *x) {
    TREE root = (TREE)malloc(sizeof(struct NODE)); // Allocate memory for the node
    root->label = STRDUP(x);        // Duplicate and set the label for the node
    root->leftmostChild = NULL;     // Set leftmostChild to NULL (no children)
    root->rightSibling = NULL;      // Set rightSibling to NULL (no siblings)
    return root;                    // Return the created node
}

// Function to create a parse tree node with one child
TREE node1(const char *x, TREE t) {
    TREE root = node0(x);           // Create the node
    root->leftmostChild = t;        // Set the leftmostChild to t
    return root;                    // Return the created node
}

// Function to create a parse tree node with two children
TREE node2(const char *x, TREE t1, TREE t2) {
    TREE root = node0(x);           // Create the node
    root->leftmostChild = t1;       // Set the leftmostChild to t1
    t1->rightSibling = t2;          // Link t1 and t2 as siblings
    return root;                    // Return the created node
}

// Function to get the index of a non-terminal in the parsing table
int getNonTerminalIndex(ParsingTable *pt, char *nonTerminal) {
    for (int i = 0; i < pt->numNonTerminals; i++) {
        if (strcmp(pt->nonTerminals[i], nonTerminal) == 0) {
            return i;               // Return the index if the non-terminal is found
        }
    }
    // If not found, add the new non-terminal and return its index
    strcpy(pt->nonTerminals[pt->numNonTerminals], nonTerminal);
    return pt->numNonTerminals++;   // Return the index and increment the count
}

// Function to get the index of a terminal in the parsing table
int getTerminalIndex(ParsingTable *pt, char *terminal) {
    for (int i = 0; i < pt->numTerminals; i++) {
        if (strcmp(pt->terminals[i], terminal) == 0) {
            return i;               // Return the index if the terminal is found
        }
    }
    // If not found, add the new terminal and return its index
    strcpy(pt->terminals[pt->numTerminals], terminal);
    return pt->numTerminals++;      // Return the index and increment the count
}

// Function to CREATE the PARSING TABLE based on grammar productions
ParsingTable *createParsingTable(Production productions[], int numProductions) {
    ParsingTable *pt = (ParsingTable *)malloc(sizeof(ParsingTable)); // Allocate memory
    pt->numNonTerminals = 0;     // Initialize count of non-terminals
    pt->numTerminals = 0;        // Initialize count of terminals

    // Initialize parsing table entries to -1 (no production)
    for (int i = 0; i < MAX_SYMBOLS; i++) {
        for (int j = 0; j < MAX_SYMBOLS; j++) {
            pt->parsingTable[i][j] = -1;  // -1 indicates no production for that entry
        }
    }

    // Fill non-terminals and terminals from productions
    for (int i = 0; i < numProductions; i++) {
        getNonTerminalIndex(pt, productions[i].lhs); // Add the left-hand side non-terminal
        for (int j = 0; j < productions[i].rhsCount; j++) {
            char *symbol = productions[i].rhs[j];
            if (!isupper(symbol[0])) {  // If the symbol is a terminal or epsilon
                if (strcmp(symbol, "e") != 0) {  // Ignore epsilon as a terminal
                    getTerminalIndex(pt, symbol); // Add terminal
                }
            }
        }
    }

    // Add necessary terminals explicitly 
    getTerminalIndex(pt, "+");
    getTerminalIndex(pt, "-");
    getTerminalIndex(pt, "*");
    getTerminalIndex(pt, "/");
    getTerminalIndex(pt, "(");
    getTerminalIndex(pt, ")");
    getTerminalIndex(pt, "$"); // End of input marker

    // Add digits '0' to '9'
    for (char c = '0'; c <= '9'; c++) {
        char s[2] = {c, '\0'};
        getTerminalIndex(pt, s);
    }

    return pt; // Return the created parsing table
}

// Function to populate the parsing table with grammar production indices
void populateTable(ParsingTable *pt) {
    // Assuming productions are in order from P1 to P26
    // Production indices start at 0

    // Production indices:
    // P1: E -> T U
    // P2: U -> + E
    // P3: U -> - E
    // P4: U -> e
    // P5: T -> F G
    // P6: G -> * T
    // P7: G -> / T
    // P8: G -> e
    // P9: F -> + F
    // P10: F -> - F
    // P11: F -> A
    // P12: A -> ( E )
    // P13: A -> N
    // P14: N -> D M
    // P15: M -> N
    // P16: M -> e
    // P17-P26: D -> 0-9

    // Get indices for non-terminals
    int nt_E = getNonTerminalIndex(pt, "E");
    int nt_U = getNonTerminalIndex(pt, "U");
    int nt_T = getNonTerminalIndex(pt, "T");
    int nt_G = getNonTerminalIndex(pt, "G");
    int nt_F = getNonTerminalIndex(pt, "F");
    int nt_A = getNonTerminalIndex(pt, "A");
    int nt_N = getNonTerminalIndex(pt, "N");
    int nt_M = getNonTerminalIndex(pt, "M");
    int nt_D = getNonTerminalIndex(pt, "D");

    // Get indices for terminals
    int t_plus = getTerminalIndex(pt, "+");
    int t_minus = getTerminalIndex(pt, "-");
    int t_times = getTerminalIndex(pt, "*");
    int t_divide = getTerminalIndex(pt, "/");
    int t_lparen = getTerminalIndex(pt, "(");
    int t_rparen = getTerminalIndex(pt, ")");
    int t_eof = getTerminalIndex(pt, "$");

    // Map digits 0-9 to their indices
    int t_digits[10];
    for (char c = '0'; c <= '9'; c++) {
        char s[2] = {c, '\0'};
        t_digits[c - '0'] = getTerminalIndex(pt, s);
    }

    // populate parsing table entries based on productions

    // P1: E -> T U
    pt->parsingTable[nt_E][t_plus] = 0;    // P1 for '+'
    pt->parsingTable[nt_E][t_minus] = 0;   // P1 for '-'
    pt->parsingTable[nt_E][t_lparen] = 0;  // P1 for '('
    for (int i = 0; i < 10; i++) {
        pt->parsingTable[nt_E][t_digits[i]] = 0; // P1 for digits '0'-'9'
    }

    // P2: U -> + E
    pt->parsingTable[nt_U][t_plus] = 1;

    // P3: U -> - E
    pt->parsingTable[nt_U][t_minus] = 2;

    // P4: U -> e
    pt->parsingTable[nt_U][t_times] = 3;
    pt->parsingTable[nt_U][t_divide] = 3;
    pt->parsingTable[nt_U][t_rparen] = 3;
    pt->parsingTable[nt_U][t_eof] = 3;

    // P5: T -> F G
    pt->parsingTable[nt_T][t_plus] = 4;
    pt->parsingTable[nt_T][t_minus] = 4;
    pt->parsingTable[nt_T][t_lparen] = 4;
    for (int i = 0; i < 10; i++) {
        pt->parsingTable[nt_T][t_digits[i]] = 4;
    }

    // P6: G -> * T
    pt->parsingTable[nt_G][t_times] = 5;

    // P7: G -> / T
    pt->parsingTable[nt_G][t_divide] = 6;

    // P8: G -> e
    pt->parsingTable[nt_G][t_plus] = 7;
    pt->parsingTable[nt_G][t_minus] = 7;
    pt->parsingTable[nt_G][t_rparen] = 7;
    pt->parsingTable[nt_G][t_eof] = 7;

    // P9: F -> + F
    pt->parsingTable[nt_F][t_plus] = 8;

    // P10: F -> - F
    pt->parsingTable[nt_F][t_minus] = 9;

    // P11: F -> A
    pt->parsingTable[nt_F][t_lparen] = 10;
    for (int i = 0; i < 10; i++) {
        pt->parsingTable[nt_F][t_digits[i]] = 10;
    }

    // P12: A -> ( E )
    pt->parsingTable[nt_A][t_lparen] = 11;

    // P13: A -> N
    for (int i = 0; i < 10; i++) {
        pt->parsingTable[nt_A][t_digits[i]] = 12;
    }

    // P14: N -> D M
    for (int i = 0; i < 10; i++) {
        pt->parsingTable[nt_N][t_digits[i]] = 13;
    }

    // P15: M -> N
    for (int i = 0; i < 10; i++) {
        pt->parsingTable[nt_M][t_digits[i]] = 14;
    }

    // P16: M -> e
    pt->parsingTable[nt_M][t_plus] = 15;
    pt->parsingTable[nt_M][t_minus] = 15;
    pt->parsingTable[nt_M][t_times] = 15;
    pt->parsingTable[nt_M][t_divide] = 15;
    pt->parsingTable[nt_M][t_rparen] = 15;
    pt->parsingTable[nt_M][t_eof] = 15;

    // P17-P26: D -> 0-9
    for (int i = 0; i < 10; i++) {
        pt->parsingTable[nt_D][t_digits[i]] = 16 + i;
    }
}

// Function to print the parsing table
void printParsingTable(ParsingTable *pt) {
    int colWidth = 6; // Column width for formatting
    printf("\nParsing Table:\n");
    printf("%-*s", colWidth, ""); // Empty top-left corner
    for (int j = 0; j < pt->numTerminals; j++) {
        printf("%-*s", colWidth, pt->terminals[j]); // Print terminals as headers
    }
    printf("\n");

    for (int i = 0; i < pt->numNonTerminals; i++) {
        printf("%-*s", colWidth, pt->nonTerminals[i]); // Print non-terminal
        for (int j = 0; j < pt->numTerminals; j++) {
            int prodIdx = pt->parsingTable[i][j];
            if (prodIdx != -1) {
                printf("P%-5d", prodIdx + 1); // Print production number (P1, P2, etc.)
            } else {
                printf("%-*s", colWidth, "-"); // Print '-' for empty entries
            }
        }
        printf("\n");
    }
}

/*
    Function for table-driven parsing using the parsing table.
    Returns the root of the parse tree if successful, or FAILED on error.
*/
TREE tableDrivenParse(ParsingTable *pt, Production productions[], int numProductions, char *input) {
    Stack stack;
    stack.top = -1;   // Initialize the stack with an empty top

    // Push the end-of-input marker ('$') and start symbol ('E') onto the stack
    stack.top++;
    strcpy(stack.symbols[stack.top], "$");
    stack.nodes[stack.top] = node0("$");

    stack.top++;
    strcpy(stack.symbols[stack.top], "E"); // Start symbol
    stack.nodes[stack.top] = node0("E");

    TREE root = stack.nodes[stack.top]; // Root of the parse tree

    nextTerm = input;   // Set the input pointer

    while (stack.top >= 0) {   // While there are symbols on the stack
        char stackSymbol[MAX_SYMBOL_SIZE];   // Store the top symbol from the stack
        strcpy(stackSymbol, stack.symbols[stack.top]);
        TREE currentNode = stack.nodes[stack.top];  // Get the current node from the stack
        stack.top--;   // Pop the top of the stack

        skipWhitespace();   // Skip spaces in the input

        // Check if the stack symbol is a terminal
        bool isTerminal = false;
        for (int i = 0; i < pt->numTerminals; i++) {
            if (strcmp(pt->terminals[i], stackSymbol) == 0) {
                isTerminal = true;   // Mark it as a terminal
                break;
            }
        }

        if (isTerminal) {   // If the stack symbol is a terminal
            if (strcmp(stackSymbol, "$") == 0) {   // Check if it's the end of input
                if (*nextTerm == '\0') {   // Check if input is fully consumed
                    return root;   // Return the parse tree
                } else {
                    printf("Error: Extra input remaining.\n");  // Unmatched input
                    return FAILED;
                }
            }

            if (*nextTerm == '\0') {   // Unexpected end of input
                printf("Error: Unexpected end of input. Expected '%s'.\n", stackSymbol);
                return FAILED;
            }

            if (strcmp(stackSymbol, (char[]){*nextTerm, '\0'}) == 0) {   // Match terminal
                match(*nextTerm);   // Consume the terminal
            } else {
                printf("Error: Mismatch. Expected '%s', found '%c'.\n", stackSymbol, *nextTerm);
                return FAILED;
            }
        } else {   // If the stack symbol is a non-terminal
            // Consult the parsing table to find the corresponding production
            char currentTerminal[MAX_SYMBOL_SIZE];
            if (*nextTerm == '\0') {
                strcpy(currentTerminal, "$");
            } else {
                currentTerminal[0] = *nextTerm;
                currentTerminal[1] = '\0';
            }

            int currentTermIdx = getTerminalIndex(pt, currentTerminal);
            if (currentTermIdx == -1) {   // Terminal not found in the parsing table
                printf("Error: Terminal '%s' not found in parsing table.\n", currentTerminal);
                return FAILED;
            }

            int nonTermIdx = getNonTerminalIndex(pt, stackSymbol);
            int prodIdx = pt->parsingTable[nonTermIdx][currentTermIdx];   // Find production

            if (prodIdx == -1) {   // No production found for this non-terminal and terminal
                printf("Error: No production found for non-terminal '%s' with terminal '%s'.\n", stackSymbol, currentTerminal);
                return FAILED;
            }

            // Retrieve production
            Production prod = productions[prodIdx];

            // Create child nodes for the parse tree
            TREE parent = currentNode;
            TREE lastChild = NULL;

            // If the production is epsilon (e)
            if (prod.rhsCount == 1 && strcmp(prod.rhs[0], "e") == 0) {
                TREE epsilonNode = node0("e");  // Create a node for epsilon
                if (parent->leftmostChild == NULL) {
                    parent->leftmostChild = epsilonNode;   // Attach epsilon as the leftmost child
                } else {
                    lastChild = parent->leftmostChild;
                    while (lastChild->rightSibling != NULL) {
                        lastChild = lastChild->rightSibling;
                    }
                    lastChild->rightSibling = epsilonNode;   // Attach as the right sibling
                }
                continue;   // No symbols to push
            }

            // Push RHS symbols to the stack in reverse order
            TREE firstChild = NULL;
            for (int i = prod.rhsCount - 1; i >= 0; i--) {
                char *symbol = prod.rhs[i];   // Get the symbol
                TREE childNode = node0(symbol);   // Create a parse tree node

                stack.top++;   // Push symbol onto the stack
                strcpy(stack.symbols[stack.top], symbol);
                stack.nodes[stack.top] = childNode;

                if (firstChild == NULL) {
                    firstChild = childNode;   // First child is the leftmost child
                } else {
                    childNode->rightSibling = firstChild;   // Link siblings
                    firstChild = childNode;
                }
            }

            // Attach the children to the parent node
            parent->leftmostChild = firstChild;
        }
    }

    // If the stack is empty but input is not fully consumed
    if (*nextTerm != '\0') {
        printf("Error: Input not fully consumed.\n");
        return FAILED;
    }

    return root;   // Return the parse tree
}

// Function to free the parse tree
void freeTree(TREE root) {
    if (root == NULL) return;
    freeTree(root->leftmostChild);
    freeTree(root->rightSibling);
    free(root->label);
    free(root);
}

// Main function to run the parser
int main() {
    char input[256];   // Buffer to store user input

    // Define grammar productions
    Production productions[MAX_PRODUCTIONS];
    int numProductions = 0;   // Counter for number of productions

    // Define the grammar productions
    // P1: E -> T U
    strcpy(productions[numProductions].lhs, "E");             // Left-hand side
    strcpy(productions[numProductions].rhs[0], "T");          // Right-hand side symbol 1
    strcpy(productions[numProductions].rhs[1], "U");          // Right-hand side symbol 2
    productions[numProductions].rhsCount = 2;                 // Number of RHS symbols
    numProductions++;                                         // Increment production count

    // P2: U -> + E
    strcpy(productions[numProductions].lhs, "U");
    strcpy(productions[numProductions].rhs[0], "+");
    strcpy(productions[numProductions].rhs[1], "E");
    productions[numProductions].rhsCount = 2;
    numProductions++;

    // P3: U -> - E
    strcpy(productions[numProductions].lhs, "U");
    strcpy(productions[numProductions].rhs[0], "-");
    strcpy(productions[numProductions].rhs[1], "E");
    productions[numProductions].rhsCount = 2;
    numProductions++;

    // P4: U -> e (epsilon)
    strcpy(productions[numProductions].lhs, "U");
    strcpy(productions[numProductions].rhs[0], "e");
    productions[numProductions].rhsCount = 1;
    numProductions++;

    // P5: T -> F G
    strcpy(productions[numProductions].lhs, "T");
    strcpy(productions[numProductions].rhs[0], "F");
    strcpy(productions[numProductions].rhs[1], "G");
    productions[numProductions].rhsCount = 2;
    numProductions++;

    // P6: G -> * T
    strcpy(productions[numProductions].lhs, "G");
    strcpy(productions[numProductions].rhs[0], "*");
    strcpy(productions[numProductions].rhs[1], "T");
    productions[numProductions].rhsCount = 2;
    numProductions++;

    // P7: G -> / T
    strcpy(productions[numProductions].lhs, "G");
    strcpy(productions[numProductions].rhs[0], "/");
    strcpy(productions[numProductions].rhs[1], "T");
    productions[numProductions].rhsCount = 2;
    numProductions++;

    // P8: G -> e (epsilon)
    strcpy(productions[numProductions].lhs, "G");
    strcpy(productions[numProductions].rhs[0], "e");
    productions[numProductions].rhsCount = 1;
    numProductions++;

    // P9: F -> + F
    strcpy(productions[numProductions].lhs, "F");
    strcpy(productions[numProductions].rhs[0], "+");
    strcpy(productions[numProductions].rhs[1], "F");
    productions[numProductions].rhsCount = 2;
    numProductions++;

    // P10: F -> - F
    strcpy(productions[numProductions].lhs, "F");
    strcpy(productions[numProductions].rhs[0], "-");
    strcpy(productions[numProductions].rhs[1], "F");
    productions[numProductions].rhsCount = 2;
    numProductions++;

    // P11: F -> A
    strcpy(productions[numProductions].lhs, "F");
    strcpy(productions[numProductions].rhs[0], "A");
    productions[numProductions].rhsCount = 1;
    numProductions++;

    // P12: A -> ( E )
    strcpy(productions[numProductions].lhs, "A");
    strcpy(productions[numProductions].rhs[0], "(");
    strcpy(productions[numProductions].rhs[1], "E");
    strcpy(productions[numProductions].rhs[2], ")");
    productions[numProductions].rhsCount = 3;
    numProductions++;

    // P13: A -> N
    strcpy(productions[numProductions].lhs, "A");
    strcpy(productions[numProductions].rhs[0], "N");
    productions[numProductions].rhsCount = 1;
    numProductions++;

    // P14: N -> D M
    strcpy(productions[numProductions].lhs, "N");
    strcpy(productions[numProductions].rhs[0], "D");
    strcpy(productions[numProductions].rhs[1], "M");
    productions[numProductions].rhsCount = 2;
    numProductions++;

    // P15: M -> N
    strcpy(productions[numProductions].lhs, "M");
    strcpy(productions[numProductions].rhs[0], "N");
    productions[numProductions].rhsCount = 1;
    numProductions++;

    // P16: M -> e (epsilon)
    strcpy(productions[numProductions].lhs, "M");
    strcpy(productions[numProductions].rhs[0], "e");
    productions[numProductions].rhsCount = 1;
    numProductions++;

    // P17-P26: D -> 0-9 (10 productions for digits 0 - 9)
    for (char c = '0'; c <= '9'; c++) {
        strcpy(productions[numProductions].lhs, "D");
        productions[numProductions].rhs[0][0] = c;       // Set RHS to digit c
        productions[numProductions].rhs[0][1] = '\0';    // Null-terminate the string
        productions[numProductions].rhsCount = 1;        // Single symbol RHS
        numProductions++;
    }

    // Create the parsing table
    ParsingTable *pt = createParsingTable(productions, numProductions);

    // Populate the parsing table with production entries
    populateTable(pt);

    // Print the parsing table (for debugging)
    printParsingTable(pt);

    // Main loop for testing input strings
    while (1) {
        // Prompts
        printf("\nChoose Parsing Method:\n");
        printf("1. Recursive-Descent Parsing\n");
        printf("2. Table-Driven Parsing\n");
        printf("Enter parsing method (1 or 2) or \"quit\" to exit: ");

        char methodInput[10]; //char array (string) that temporarily stores user input
        if (fgets(methodInput, sizeof(methodInput), stdin) == NULL) {
            printf("Error reading input. Exiting.\n");
            break;
        }

        // Remove newline character
        methodInput[strcspn(methodInput, "\n")] = '\0';

        // Check if quit
        if (strcmp(methodInput, "quit") == 0) {
            printf("Bye.\n");
            break;
        }

        // Convert methodInput to integer
        int parsingMethod;
        if (sscanf(methodInput, "%d", &parsingMethod) != 1) {
            printf("Invalid input. Please enter 1, 2, or \"quit\".\n");
            continue;
        }
        // If anything other than 1 or 2
        if (parsingMethod != 1 && parsingMethod != 2) {
            printf("Invalid parse method. Please choose 1 or 2.\n");
            continue;
        }

        // Prompt for input expressions
        printf("Enter input to test (\"quit\" to quit): ");
        while (fgets(input, sizeof(input), stdin)) {   // Read input from the user
            input[strcspn(input, "\n")] = '\0';        // Remove newline character
            if (strcmp(input, "quit") == 0) {          // Exit if input is "quit"
                printf("Bye.\n");
                free(pt); // Free the parsing table memory before exiting
                return 0;
            }
            printf("Testing input: \"%s\"\n", input);

            // Choose the appropriate parsing method
            if (parsingMethod == 1) {
                // Recursive-descent parsing
                nextTerm = input;                      // Set input pointer
                parseTree = E();                       // Parse starting from E
                skipWhitespace();                      // Skip trailing spaces
                if (parseTree != FAILED && *nextTerm == '\0') {   // If input is valid
                    printTree(parseTree);              // Print the parse tree
                    freeTree(parseTree);               // Free the parse tree after use
                } else {
                    printf("Error: Invalid input.\n"); // Error in input
                }
            } else if (parsingMethod == 2) {
                // Table-driven parsing
                parseTree = tableDrivenParse(pt, productions, numProductions, input);  // Start table-driven parse
                skipWhitespace();                      // Skip trailing spaces
                if (parseTree != FAILED && *nextTerm == '\0') {   // If input is valid
                    printTree(parseTree);              // Print the parse tree
                    freeTree(parseTree);               // Free the parse tree after use
                } else {
                    printf("Error: Invalid input.\n"); // Error in input
                }
            }

            // Prompt for another input
            printf("\nEnter input to test (\"quit\" to quit): ");
        }

        // If fgets fails
        printf("Error reading input. Exiting.\n");
        break;
    }

    // Free the parsing table memory before exiting
    free(pt);

    return 0;   // End of the program
}
