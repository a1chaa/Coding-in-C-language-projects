/*
CSC173
Aichata Doumbia adoumbi2@u.rochester.edu/   
31596312
PROJECT4

cd ~/4PROJECT173_ADOUMBI2
gcc -std=c99 -Wall -Werror -o vehicle_db main.c Database.c
./vehicle_db


*/



/* =============================================================
   Vehicle‑License schema  —  Database.h
   ============================================================= */
#ifndef VEHICLE_DATABASE_H
#define VEHICLE_DATABASE_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define TABLE_SIZE 1009

/* ----------  LNAC  (LicenseId, Name, Address, County)  -------- */
typedef struct LNACTuple *LNACTupleList;
struct LNACTuple {
    int  LicenseId;
    char Name[30];
    char Address[40];
    char County[20];
    LNACTupleList next;
};
typedef LNACTupleList LNACHashTable[TABLE_SIZE];

/* ----------  VL  (Vehicle, LicenseId)  ------------------------ */
typedef struct VLTuple *VLTupleList;
struct VLTuple {
    char Vehicle[10];
    int  LicenseId;
    VLTupleList next;
};
typedef VLTupleList VLHashTable[TABLE_SIZE];

/* ----------  VDR  (Vehicle, Date, Result)  -------------------- */
typedef struct VDRTuple *VDRTupleList;
struct VDRTuple {
    char Vehicle[10];
    char Date[11];     /* YYYY‑MM‑DD */
    char Result[5];    /* “pass” / “fail” */
    VDRTupleList next;
};
typedef VDRTupleList VDRHashTable[TABLE_SIZE];

/* ----------  VM  (Vehicle, Manufacturer)  --------------------- */
typedef struct VMTuple *VMTupleList;
struct VMTuple {
    char Vehicle[10];
    char Manufacturer[15];
    VMTupleList next;
};
typedef VMTupleList VMHashTable[TABLE_SIZE];

/* ----------  LR  (LicenseId, Relative)  ----------------------- */
typedef struct LRTuple *LRTupleList;
struct LRTuple {
    int  LicenseId;
    int  Relative;          /* another LicenseId */
    LRTupleList next;
};
typedef LRTupleList LRHashTable[TABLE_SIZE];

/* ----------  Helper result lists (for projection / joins) ----- */
typedef struct VehicleTuple *VehicleTupleList;   /* projection list */
struct VehicleTuple { char Vehicle[10]; VehicleTupleList next; };

typedef struct VDMTuple *VDMTupleList;           /* join VM ▷◁ VDR */
struct VDMTuple {
    char Vehicle[10];
    char Date[11];
    char Manufacturer[15];
    VDMTupleList next;
};

/* ----------  hash function  ----------------------------------- */
unsigned long hash_function(const char *str);

/* ==========  INSERTS  ========================================= */
void insert_LNAC(LNACHashTable t, int id,
                 const char *name, const char *addr, const char *county);
void insert_VL  (VLHashTable  t, const char *veh, int id);
void insert_VDR (VDRHashTable t, const char *veh,
                 const char *date, const char *result);
void insert_VM  (VMHashTable  t, const char *veh, const char *manu);
void insert_LR  (LRHashTable  t, int id, int rel);

/* ==========  DELETES  ========================================= */
void delete_LNAC(LNACHashTable t, int id,
                 const char *name, const char *addr, const char *county);
void delete_VL  (VLHashTable  t, const char *veh, int id);
void delete_VDR (VDRHashTable t, const char *veh,
                 const char *date, const char *result);
void delete_VM  (VMHashTable  t, const char *veh, const char *manu);
void delete_LR  (LRHashTable  t, int id, int rel);

/* ==========  LOOK‑UPS  (wildcards via NULL / ‑1) =============== */
LNACTupleList lookup_LNAC(LNACHashTable t, int id,
                          const char *name, const char *addr, const char *county);
VLTupleList    lookup_VL  (VLHashTable  t, const char *veh, int id);
VDRTupleList   lookup_VDR (VDRHashTable t, const char *veh,
                           const char *date, const char *result);
VMTupleList    lookup_VM  (VMHashTable  t, const char *veh, const char *manu);
LRTupleList    lookup_LR  (LRHashTable  t, int id, int rel);

/* ==========  PRINTING  ======================================== */
void print_LNAC(LNACHashTable t);
void print_VL  (VLHashTable  t);
void print_VDR (VDRHashTable t);
void print_VM  (VMHashTable  t);
void print_LR  (LRHashTable  t);
void printAll  (LNACHashTable a, VLHashTable b, VDRHashTable c,
                VMHashTable d,  LRHashTable e);

/* ==========  REL‑ALGEBRA HELPERS  ============================== */
VLTupleList       select_VL_byLicenseId(VLHashTable t, int id);
VehicleTupleList  project_Vehicle_fromVL(VLTupleList list);
VDMTupleList      join_VM_VDR(VMHashTable vm, VDRHashTable vdr);
VDMTupleList      select_VDM_byManufacturer(VDMTupleList list,
                                            const char *manu);
VehicleTupleList  project_DateResult(VDMTupleList list);

/* ==========  DATA MANAGEMENT  ================================= */
void clear_LNAC(LNACHashTable t);
void clear_VL  (VLHashTable  t);
void clear_VDR (VDRHashTable t);
void clear_VM  (VMHashTable  t);
void clear_LR  (LRHashTable  t);

void loadDatabases(LNACHashTable, VLHashTable, VDRHashTable,
                   VMHashTable,  LRHashTable);
void resetDatabases(LNACHashTable, VLHashTable, VDRHashTable,
                    VMHashTable,  LRHashTable);

#endif /* VEHICLE_DATABASE_H */
