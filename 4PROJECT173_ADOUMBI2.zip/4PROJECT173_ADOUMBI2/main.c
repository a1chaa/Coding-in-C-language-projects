/*
CSC173
Aichata Doumbia adoumbi2@u.rochester.edu/   
31596312
PROJECT4

cd ~/4PROJECT173_ADOUMBI2
gcc -std=c99 -Wall -Werror -o vehicle_db main.c Database.c
./vehicle_db




*/

#include "Database.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


/* ===============================================================
   1.  “What vehicles does Name own?”
     
   =============================================================== */
void VehiclesFromName(LNACHashTable lnac_table, VLHashTable vl_table,
                      const char *name)
{
    int license_ids[100];
    int num_ids = 0;

    /* step‑1: collect all LicenseIds for the given name in LNAC */
    for (int i = 0; i < TABLE_SIZE; i++) {
        LNACTupleList cur = lnac_table[i];
        while (cur) {
            if (strcmp(cur->Name, name) == 0) {
                license_ids[num_ids++] = cur->LicenseId;
                printf("Found LicenseId for %s: %d\n", name, cur->LicenseId);
            }
            cur = cur->next;
        }
    }

    if (num_ids == 0) {
        printf("Driver not found. Terminating current query…\n");
        return;
    }

    /* step‑2: for each LicenseId, list the vehicles in VL         */
    int any = 0;
    for (int k = 0; k < num_ids; k++) {
        int id = license_ids[k];
        printf("Searching for vehicles linked to LicenseId: %d\n", id);

        for (int b = 0; b < TABLE_SIZE; b++) {
            VLTupleList cur = vl_table[b];
            while (cur) {
                if (cur->LicenseId == id) {
                    printf("%s owns vehicle %s\n", name, cur->Vehicle);
                    any = 1;
                }
                cur = cur->next;
            }
        }
    }

    if (!any)
        printf("No vehicles found for %s.\n", name);
}

/*  REPL wrapper */
void repl_VehiclesFromName(LNACHashTable lnac_table, VLHashTable vl_table)
{
    char name[50];
    while (1) {
        printf("Enter a driver's name (type 'quit' to quit): ");
        if (!fgets(name, sizeof(name), stdin)) break;
        name[strcspn(name, "\n")] = '\0';
        if (strcmp(name, "quit") == 0) break;

        VehiclesFromName(lnac_table, vl_table, name);
        printf("\n");
    }
}

/* ===============================================================
   2.  “On what DATE(s) did Name have a vehicle from Manufacturer
        inspected (pass/fail)?”  
   =============================================================== */
void DatesFromNameByManufacturer(LNACHashTable lnac_table,
                                 VLHashTable   vl_table,
                                 VMHashTable   vm_table,
                                 VDRHashTable  vdr_table,
                                 const char   *name,
                                 const char   *manufacturer)
{
    /* -------- step‑1: get the driver’s LicenseId ---------------- */
    int license_id = -1;
    for (int i = 0; i < TABLE_SIZE && license_id == -1; i++) {
        LNACTupleList cur = lnac_table[i];
        while (cur) {
            if (strcmp(cur->Name, name) == 0) { license_id = cur->LicenseId; break; }
            cur = cur->next;
        }
    }
    if (license_id == -1) {
        printf("Driver not found. Terminating current query…\n");
        return;
    }

    /* -------- step‑2: find all vehicles owned by that LicenseId --*/
    VLTupleList vehicle_list = NULL;
    for (int i = 0; i < TABLE_SIZE; i++) {
        VLTupleList cur = vl_table[i];
        while (cur) {
            if (cur->LicenseId == license_id) {
                VLTupleList n = malloc(sizeof(struct VLTuple));
                *n = *cur; n->next = vehicle_list; vehicle_list = n;
            }
            cur = cur->next;
        }
    }
    if (!vehicle_list) {
        printf("%s does not own any vehicles.\n", name);
        return;
    }

    /* -------- step‑3: keep only vehicles with that manufacturer --*/
    VLTupleList filtered = NULL;
    for (VLTupleList v = vehicle_list; v; v = v->next) {
        unsigned long h = hash_function(v->Vehicle);
        VMTupleList cur = vm_table[h];
        while (cur) {
            if (strcmp(cur->Vehicle, v->Vehicle) == 0 &&
                strcmp(cur->Manufacturer, manufacturer) == 0) {
                VLTupleList n = malloc(sizeof(struct VLTuple));
                *n = *v; n->next = filtered; filtered = n; break;
            }
            cur = cur->next;
        }
    }
    if (!filtered) {
        printf("No vehicles owned by %s were manufactured by %s.\n",
               name, manufacturer);
        return;
    }

    /* -------- step‑4: print inspection dates/results -------------*/
    printf("%s had the following inspections for %s vehicles:\n",
           name, manufacturer);
    int printed = 0;
    for (VLTupleList v = filtered; v; v = v->next) {
        unsigned long h = hash_function(v->Vehicle);
        VDRTupleList cur = vdr_table[h];
        while (cur) {
            if (strcmp(cur->Vehicle, v->Vehicle) == 0) {
                printf("Vehicle: %s, Date: %s, Result: %s\n",
                       cur->Vehicle, cur->Date, cur->Result);
                printed = 1;
            }
            cur = cur->next;
        }
    }
    if (!printed)
        printf("No inspection records found for the matched vehicles.\n");
}
/* ---------------------------------------------------------------
   REPL  —  “On what DATE(s) did Name have a vehicle from
             Manufacturer inspected?”
   --------------------------------------------------------------- */
void repl_DatesNameManufacturer(LNACHashTable lnac_table,
                                VLHashTable   vl_table,
                                VMHashTable   vm_table,
                                VDRHashTable  vdr_table)
{
    char name[50], manu[50];

    while (1) {
        printf("Enter a driver's name (type 'quit' to quit): ");
        if (!fgets(name, sizeof(name), stdin)) break;
        name[strcspn(name, "\n")] = '\0';
        if (strcmp(name, "quit") == 0) break;

        printf("Enter a manufacturer ( type 'quit' to quit): ");
        if (!fgets(manu, sizeof(manu), stdin)) break;
        manu[strcspn(manu, "\n")] = '\0';
        if (strcmp(manu, "quit") == 0) break;

        DatesFromNameByManufacturer(lnac_table, vl_table,
                                    vm_table, vdr_table,
                                    name, manu);
        printf("\n");
    }
}

/* ---------------------------------------------------------------
   main  —  vehicle version
   --------------------------------------------------------------- */
int main(void)
{
    LNACHashTable lnac = { NULL };
    VLHashTable   vl   = { NULL };
    VDRHashTable  vdr  = { NULL };
    VMHashTable   vm   = { NULL };
    LRHashTable   lr   = { NULL };

    /* ----------  PART1  -------------------------------------- */
    puts("First step, loading the databases for PART 1:");
    loadDatabases(lnac, vl, vdr, vm, lr);
    printAll(lnac, vl, vdr, vm, lr);

    /* a) lookup (⟨“QYOO289”,“2025‑02‑11”,*⟩, Vehicle‑Date‑Result) */
    puts("a) lookup (⟨\"QYOO289\",\"2025-02-11\",*⟩, Vehicle-Date-Result)");
    lookup_VDR(vdr, "QYOO289", "2025-02-11", NULL);  puts("");

    /* b) lookup (⟨*,“H. Cook”,*,*⟩, LicenseId‑Name‑Address‑County) */
    puts("b) lookup (⟨*, \"H. Cook\", *, *⟩, LicenseId-Name-Address-County)");
    lookup_LNAC(lnac, -1, "H. Cook", NULL, NULL);   puts("");

    /* c) lookup(⟨300085,801544⟩, LicenseId‑Relative) */
    puts("c) lookup(⟨300085,801544⟩, LicenseId-Relative)");
    lookup_LR(lr, 300085, 801544);                  puts("");

    /* d) delete (⟨“BGRY698”,“Subaru”⟩, Vehicle‑Manufacturer) */
    puts("d) delete (⟨\"BGRY698\",\"Subaru\"⟩, Vehicle-Manufacturer)");
    delete_VM(vm, "BGRY698", "Subaru");
    print_VM(vm);                                   puts("");

    /* e) delete(⟨*,“Mini”⟩, Vehicle‑Manufacturer) */
    puts("e) delete(⟨*, \"Mini\"⟩, Vehicle-Manufacturer)");
    delete_VM(vm, NULL, "Mini");
    print_VM(vm);                                   puts("");

    /* f) delete(⟨*,“2024‑01‑01”,*⟩, Vehicle‑Date‑Result) */
    puts("f) delete(⟨*, \"2024-01-01\", *⟩, Vehicle-Date-Result)");
    delete_VDR(vdr, NULL, "2024-01-01", NULL);
    print_VDR(vdr);                                 puts("");

    /* g) insert(⟨832956,496145⟩, LicenseId‑Relative) */
    puts("g) insert(⟨832956,496145⟩, LicenseId-Relative)");
    insert_LR(lr, 832956, 496145);
    print_LR(lr);                                   puts("");

    /* h) insert(⟨832956,884422⟩, LicenseId‑Relative) */
    puts("h) insert(⟨832956,884422⟩, LicenseId-Relative)");
    insert_LR(lr, 832956, 884422);
    print_LR(lr);                                   puts("");

    /* ----------  PART2 : Q1  --------------------------------- */
    puts("Preparing for PART 2 question 1… Resetting the relations…");
    resetDatabases(lnac, vl, vdr, vm, lr);

    puts("What vehicles does NAME own?");
    repl_VehiclesFromName(lnac, vl);
    puts("\nEnd of Question 1. Moving on to Question 2…\n");

    /* ----------  PART2 : Q2  --------------------------------- */
    puts("Preparing for PART 2 question 2… Resetting the relations…");
    resetDatabases(lnac, vl, vdr, vm, lr);

    puts("On what DATE(s) did NAME have a MANUFACTURER vehicle inspected?");
    repl_DatesNameManufacturer(lnac, vl, vm, vdr);
    puts("\nEnd of Question 2.  END OF PART 2.\n");

    /* ----------  PART 3  -------------------------------------- */
    puts("Beginning PART 3…");
    resetDatabases(lnac, vl, vdr, vm, lr);

    /* σLicenseId=801544(VL)  */
    puts("Selection: σLicenseId=801544(VL)");
    VLTupleList sel = select_VL_byLicenseId(vl, 801544);
    for (VLTupleList c = sel; c; c = c->next)
        printf("| %-10s |\n", c->Vehicle);
    puts("");

    /* πVehicle(σLicenseId=801544(VL)) */
    puts("Projection: πVehicle(σLicenseId=801544(VL))");
    VehicleTupleList proj = project_Vehicle_fromVL(sel);
    for (VehicleTupleList c = proj; c; c = c->next)
        printf("| %-10s |\n", c->Vehicle);
    puts("");

    /* VM ▷◁ VDR */
    puts("Join: VM ▷◁ VDR");
    VDMTupleList join = join_VM_VDR(vm, vdr);
    for (VDMTupleList c = join; c; c = c->next)
        printf("| %-10s | %-10s | %-10s |\n",
               c->Vehicle, c->Date, c->Manufacturer);
    puts("");

    /* πDate,Result(σManufacturer=\"Ford\"(VM▷◁VDR)) */
    puts("πDate,Result(σManufacturer=\"Ford\"(VM▷◁VDR))");
    VDMTupleList ford = select_VDM_byManufacturer(join, "Ford");
    for (VDMTupleList c = ford; c; c = c->next)
        printf("| %-10s | %-10s |\n", c->Date, c->Manufacturer);
    puts("");

    return 0;
}
