/*
CSC173
Aichata Doumbia adoumbi2@u.rochester.edu/   
31596312
PROJECT4

cd ~/4PROJECT173_ADOUMBI2
gcc -std=c99 -Wall -Werror -o vehicle_db main.c Database.c
./vehicle_db

*/





/* ===============================================================
   Vehicle‑License schema  —  inserts / deletes
   (drop these into Database.c, replacing the race versions)
   =============================================================== */
#include "Database.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


unsigned long hash_function(const char *str)
{
    unsigned long h = 5381; int c;
    while ((c = *str++)) h = ((h << 5) + h) + c;
    return h % TABLE_SIZE;
}

/* ----------------  INSERTS  ---------------------------------- */
void insert_LNAC(LNACHashTable t, int id,
                 const char *name, const char *addr, const char *county)
{
    char key[12]; sprintf(key, "%d", id);
    unsigned long idx = hash_function(key);

    for (LNACTupleList cur = t[idx]; cur; cur = cur->next)
        if (cur->LicenseId == id) {
            printf("LicenseId %d already exists in LNAC. Unable to insert.\n",
                   id);  return;
        }

    LNACTupleList n = malloc(sizeof *n);
    n->LicenseId = id;
    strcpy(n->Name, name);
    strcpy(n->Address, addr);
    strcpy(n->County, county);
    n->next = t[idx];
    t[idx] = n;
}

void insert_VL(VLHashTable t, const char *veh, int id)
{
    unsigned long idx = hash_function(veh);

    /* if that exact Vehicle/LicId pair already exists, skip */
    for (VLTupleList cur = t[idx]; cur; cur = cur->next)
        if (!strcmp(cur->Vehicle, veh) && cur->LicenseId == id) {
            printf("Entry %s/%d already in VL. Skipping.\n", veh, id);
            return;
        }

    VLTupleList n = malloc(sizeof *n);
    strcpy(n->Vehicle, veh);
    n->LicenseId = id;
    n->next = t[idx];
    t[idx] = n;
}

void insert_VDR(VDRHashTable t, const char *veh,
                const char *date, const char *result)
{
    unsigned long idx = hash_function(veh);

    for (VDRTupleList cur = t[idx]; cur; cur = cur->next)
        if (!strcmp(cur->Vehicle, veh) && !strcmp(cur->Date, date)) {
            printf("Inspection %s %s already exists. Skipping.\n", veh, date);
            return;
        }

    VDRTupleList n = malloc(sizeof *n);
    strcpy(n->Vehicle,  veh);
    strcpy(n->Date,     date);
    strcpy(n->Result,   result);
    n->next = t[idx];
    t[idx] = n;
}

void insert_VM(VMHashTable t, const char *veh, const char *manu)
{
    unsigned long idx = hash_function(veh);

    for (VMTupleList cur = t[idx]; cur; cur = cur->next)
        if (!strcmp(cur->Vehicle, veh) && !strcmp(cur->Manufacturer, manu)) {
            printf("Entry %s/%s already in VM. Skipping.\n", veh, manu);
            return;
        }

    VMTupleList n = malloc(sizeof *n);
    strcpy(n->Vehicle,       veh);
    strcpy(n->Manufacturer,  manu);
    n->next = t[idx];
    t[idx] = n;
}

void insert_LR(LRHashTable t, int id, int rel)
{
    char key[12]; sprintf(key, "%d", id);
    unsigned long idx = hash_function(key);

    for (LRTupleList cur = t[idx]; cur; cur = cur->next)
        if (cur->LicenseId == id && cur->Relative == rel) {
            printf("LR (%d,%d) already exists. Skipping.\n", id, rel);
            return;
        }

    LRTupleList n = malloc(sizeof *n);
    n->LicenseId = id;
    n->Relative  = rel;
    n->next = t[idx];
    t[idx] = n;
}

/* ----------------  DELETES  ---------------------------------- */
#define MATCHSTR(v,a) ((a)==NULL || strcmp((v),(a))==0)
#define MATCHINT(v,a) ((a)==-1   || (v)==(a))

void delete_LNAC(LNACHashTable t, int id,
                 const char *name, const char *addr, const char *county)
{
    for (int i = 0; i < TABLE_SIZE; i++) {
        LNACTupleList cur = t[i], prev = NULL;
        while (cur) {
            if (MATCHINT(cur->LicenseId,id) &&
                MATCHSTR(cur->Name,name)    &&
                MATCHSTR(cur->Address,addr) &&
                MATCHSTR(cur->County,county)) {
                if (!prev) t[i] = cur->next; else prev->next = cur->next;
                free(cur);  printf("LNAC tuple deleted.\n");
                cur = (prev ? prev->next : t[i]);
            } else { prev = cur; cur = cur->next; }
        }
    }
}

void delete_VL(VLHashTable t, const char *veh, int id)
{
    for (int i = 0; i < TABLE_SIZE; i++) {
        if (veh && i != (int)hash_function(veh)) continue;
        VLTupleList cur = t[i], prev = NULL;
        while (cur) {
            if (MATCHSTR(cur->Vehicle,veh) && MATCHINT(cur->LicenseId,id)) {
                if (!prev) t[i] = cur->next; else prev->next = cur->next;
                printf("Deleted VL: %s/%d\n", cur->Vehicle, cur->LicenseId);
                free(cur); cur = (prev ? prev->next : t[i]);
            } else { prev = cur; cur = cur->next; }
        }
    }
}

void delete_VDR(VDRHashTable t, const char *veh,
                const char *date, const char *result)
{
    for (int i = 0; i < TABLE_SIZE; i++) {
        if (veh && i != (int)hash_function(veh)) continue;
        VDRTupleList cur = t[i], prev = NULL;
        while (cur) {
            if (MATCHSTR(cur->Vehicle,veh) &&
                MATCHSTR(cur->Date,date)   &&
                MATCHSTR(cur->Result,result)) {
                if (!prev) t[i] = cur->next; else prev->next = cur->next;
                printf("Deleted VDR: %s %s\n", cur->Vehicle, cur->Date);
                free(cur); cur = (prev ? prev->next : t[i]);
            } else { prev = cur; cur = cur->next; }
        }
    }
}



/* ===============================================================
   Vehicle‑License schema — delete + lookup conversions
   
   =============================================================== */

/* ---------- delete_VM  (Vehicle, Manufacturer) ---------------- */
/* delete all matching Vehicle–Manufacturer pairs */
void delete_VM(VMHashTable table,
               const char *Vehicle,
               const char *Manufacturer)
{
    int deleted = 0;
    for (int i = 0; i < TABLE_SIZE; i++) {
        VMTupleList cur = table[i], prev = NULL;
        while (cur) {
            if ((Vehicle == NULL || strcmp(cur->Vehicle, Vehicle) == 0) &&
                (Manufacturer == NULL || strcmp(cur->Manufacturer, Manufacturer) == 0))
            {
                deleted = 1;
                VMTupleList toDelete = cur;
                if (!prev) table[i] = cur->next;
                else       prev->next = cur->next;
                cur = cur->next;  // advance before freeing
                printf("Deleted: Vehicle: %s, Manufacturer: %s\n",
                       toDelete->Vehicle, toDelete->Manufacturer);
                free(toDelete);
                // continue—don't return; keep deleting any other matches
            }
            else {
                prev = cur;
                cur  = cur->next;
            }
        }
    }
    if (!deleted)
        puts("No matching record found to delete.");
}

/* ---------- delete_LR  (LicenseId, Relative) ------------------ */


/* ---------- lookup_LNAC  -------------------------------------- */
LNACTupleList lookup_LNAC(LNACHashTable table, int LicenseId,
                          const char *Name, const char *Address,
                          const char *County)
{
    LNACTupleList result = NULL; int found = 0;
    for (int i = 0; i < TABLE_SIZE; i++) {
        for (LNACTupleList cur = table[i]; cur; cur = cur->next) {
            int match = 1;
            if (LicenseId != -1 && cur->LicenseId != LicenseId) match = 0;
            if (Name      && strcmp(cur->Name,     Name))       match = 0;
            if (Address   && strcmp(cur->Address,  Address))    match = 0;
            if (County    && strcmp(cur->County,   County))     match = 0;

            if (match) {
                found = 1;
                LNACTupleList n = malloc(sizeof *n); *n = *cur;
                n->next = result; result = n;
                printf("Desired search FOUND:\n"
                       "LicenseId: %d, Name: %s, Address: %s, County: %s\n",
                       cur->LicenseId, cur->Name, cur->Address, cur->County);
            }
        }
    }
    if (!found) puts("Desired search NOT FOUND.");
    return result;
}

/* ---------- lookup_VDR  (Vehicle, Date, Result) --------------- */
VDRTupleList lookup_VDR(VDRHashTable table,
                        const char *Vehicle,
                        const char *Date,
                        const char *Result)
{
    VDRTupleList res = NULL; int found = 0;
    for (int i = 0; i < TABLE_SIZE; i++) {
        for (VDRTupleList cur = table[i]; cur; cur = cur->next) {
            int match = 1;
            if (Vehicle && strcmp(cur->Vehicle, Vehicle)) match = 0;
            if (Date    && strcmp(cur->Date,    Date))    match = 0;
            if (Result  && strcmp(cur->Result,  Result))  match = 0;

            if (match) {
                found = 1;
                VDRTupleList n = malloc(sizeof *n); *n = *cur;
                n->next = res; res = n;
                printf("Desired search FOUND:\n"
                       "Vehicle: %s, Date: %s, Result: %s\n",
                       cur->Vehicle, cur->Date, cur->Result);
            }
        }
    }
    if (!found) puts("Desired search NOT FOUND.");
    return res;
}
/* ===============================================================
   look‑ups
   =============================================================== */
VMTupleList lookup_VM(VMHashTable table,
                      const char *Vehicle, const char *Manufacturer)
{
    VMTupleList res = NULL; int found = 0;

    for (int i = 0; i < TABLE_SIZE; i++) {
        for (VMTupleList cur = table[i]; cur; cur = cur->next) {
            int match = 1;
            if (Vehicle       && strcmp(cur->Vehicle,       Vehicle))       match = 0;
            if (Manufacturer  && strcmp(cur->Manufacturer,  Manufacturer))  match = 0;

            if (match) {
                found = 1;
                VMTupleList n = malloc(sizeof *n); *n = *cur;
                n->next = res; res = n;
                printf("Desired search FOUND:\n"
                       "Vehicle: %s, Manufacturer: %s\n",
                       cur->Vehicle, cur->Manufacturer);
            }
        }
    }
    if (!found) puts("Desired search NOT FOUND.");
    return res;
}

LRTupleList lookup_LR(LRHashTable table, int LicenseId, int Relative)
{
    LRTupleList res = NULL; int found = 0;

    for (int i = 0; i < TABLE_SIZE; i++) {
        for (LRTupleList cur = table[i]; cur; cur = cur->next) {
            int match = 1;
            if (LicenseId != -1 && cur->LicenseId != LicenseId) match = 0;
            if (Relative  != -1 && cur->Relative  != Relative)  match = 0;

            if (match) {
                found = 1;
                LRTupleList n = malloc(sizeof *n); *n = *cur;
                n->next = res; res = n;
                printf("Desired search FOUND:\n"
                       "LicenseId: %d, Relative: %d\n",
                       cur->LicenseId, cur->Relative);
            }
        }
    }
    if (!found) puts("Desired search NOT FOUND.");
    return res;
}

/* ===============================================================
   table printers
   =============================================================== */
void print_LNAC(LNACHashTable table)
{
    puts("---------------------------------------------------------------");
    printf("| %-10s | %-20s | %-20s | %-10s |\n",
           "LicenseId","Name","Address","County");
    puts("---------------------------------------------------------------");

    for (int i = 0; i < TABLE_SIZE; i++)
        for (LNACTupleList cur = table[i]; cur; cur = cur->next)
            printf("| %-10d | %-20s | %-20s | %-10s |\n",
                   cur->LicenseId, cur->Name,
                   cur->Address, cur->County);

    puts("---------------------------------------------------------------");
}

void print_VDR(VDRHashTable table)
{
    puts("----------------------------------------------------------------");
    printf("| %-10s | %-12s | %-8s |\n", "Vehicle", "Date", "Result");
    puts("----------------------------------------------------------------");

    for (int i = 0; i < TABLE_SIZE; i++)
        for (VDRTupleList cur = table[i]; cur; cur = cur->next)
            printf("| %-10s | %-12s | %-8s |\n",
                   cur->Vehicle, cur->Date, cur->Result);

    puts("----------------------------------------------------------------");
}

void print_VL(VLHashTable table)
{
    puts("------------------------------------------");
    printf("| %-10s | %-10s |\n", "Vehicle", "LicenseId");
    puts("------------------------------------------");

    for (int i = 0; i < TABLE_SIZE; i++)
        for (VLTupleList cur = table[i]; cur; cur = cur->next)
            printf("| %-10s | %-10d |\n",
                   cur->Vehicle, cur->LicenseId);

    puts("------------------------------------------");
}

void print_VM(VMHashTable table)
{
    puts("------------------------------------------");
    printf("| %-10s | %-15s |\n", "Vehicle", "Manufacturer");
    puts("------------------------------------------");

    for (int i = 0; i < TABLE_SIZE; i++)
        for (VMTupleList cur = table[i]; cur; cur = cur->next)
            printf("| %-10s | %-15s |\n",
                   cur->Vehicle, cur->Manufacturer);

    puts("------------------------------------------");
}


/* ----------  print_LR  (LicenseId, Relative)  ----------------- */
void print_LR(LRHashTable table) {
    puts("---------------------------------------------");
    printf("| %-10s | %-10s |\n", "LicenseId", "Relative");
    puts("---------------------------------------------");
    for (int i = 0; i < TABLE_SIZE; i++) {
        for (LRTupleList cur = table[i]; cur; cur = cur->next) {
            printf("| %-10d | %-10d |\n",
                   cur->LicenseId, cur->Relative);
        }
    }
    puts("---------------------------------------------");
}

/* ----------  printAll  (LNAC, VL, VDR, VM, LR)  --------------- */
void printAll(LNACHashTable lnac, VLHashTable vl,
              VDRHashTable vdr, VMHashTable vm, LRHashTable lr)
{
    puts("Printing LNAC...");
    print_LNAC(lnac);
    putchar('\n');
    puts("Printing VDR...");
    print_VDR(vdr);
    putchar('\n');
    puts("Printing VL...");
    print_VL(vl);
    putchar('\n');
    puts("Printing VM...");
    print_VM(vm);
    putchar('\n');
    puts("Printing LR...");
    print_LR(lr);
    putchar('\n');
}

/* ----------  loadDatabases  (vehicle sample data) ------------ */
void loadDatabases(LNACHashTable lnac, VLHashTable vl,
                   VDRHashTable vdr, VMHashTable vm, LRHashTable lr)
{
    // LNAC
    insert_LNAC(lnac, 496145, "H. Cook",   "769 Park Ave", "Columbia");
    insert_LNAC(lnac, 471638, "E. Jones",  "144 Church St","Allegany");
    insert_LNAC(lnac, 832956, "H. Cook",   "47 Smith St", "Genesee");
    insert_LNAC(lnac, 300085, "L. Cooper", "666 9th St",  "Allegany");
    insert_LNAC(lnac, 801544, "E. Jones",  "817 Cedar St","Montgomery");
    insert_LNAC(lnac, 413519, "C. Johnson","824 1st Ave", "Yates");

    // VDR (inspections)
    insert_VDR(vdr, "QYOO289", "2025-02-11", "fail");
    insert_VDR(vdr, "IJQY102", "2025-02-18", "fail");
    insert_VDR(vdr, "IJQY102", "2025-02-14", "pass");
    insert_VDR(vdr, "QYOO289", "2025-03-31", "fail");
    insert_VDR(vdr, "NWWT998", "2025-02-18", "pass");

    // VL (ownership)
    insert_VL(vl, "MQVX440", 471638);
    insert_VL(vl, "BGRY698", 832956);
    insert_VL(vl, "KOZO629", 801544);
    insert_VL(vl, "CJLX293", 801544);
    insert_VL(vl, "QYOO289", 471638);
    insert_VL(vl, "XTXZ596", 496145);

    // VM (manufacturers)
    insert_VM(vm, "MQVX440", "Mini");
    insert_VM(vm, "NWWT998", "Ford");
    insert_VM(vm, "BGRY698", "Subaru");
    insert_VM(vm, "QYOO289", "Honda");
    insert_VM(vm, "XTXZ596", "Ford");
    insert_VM(vm, "ZXCP464", "Mini");

    // LR (relatives)
    insert_LR(lr, 801544, 300085);
    insert_LR(lr, 832956, 496145);
    insert_LR(lr, 413519, 471638);
    insert_LR(lr, 471638, 801544);
    insert_LR(lr, 832956, 413519);
    insert_LR(lr, 801544, 832956);
}

/* ----------  clear_*  (wipe all buckets)  -------------------- */
void clear_LNAC(LNACHashTable t) {
    for (int i = 0; i < TABLE_SIZE; i++) {
        LNACTupleList cur = t[i];
        while (cur) {
            LNACTupleList nxt = cur->next;
            free(cur);
            cur = nxt;
        }
        t[i] = NULL;
    }
}
void clear_VL(VLHashTable t) {
    for (int i = 0; i < TABLE_SIZE; i++) {
        VLTupleList cur = t[i];
        while (cur) {
            VLTupleList nxt = cur->next;
            free(cur);
            cur = nxt;
        }
        t[i] = NULL;
    }
}
void clear_VDR(VDRHashTable t) {
    for (int i = 0; i < TABLE_SIZE; i++) {
        VDRTupleList cur = t[i];
        while (cur) {
            VDRTupleList nxt = cur->next;
            free(cur);
            cur = nxt;
        }
        t[i] = NULL;
    }
}
void clear_VM(VMHashTable t) {
    for (int i = 0; i < TABLE_SIZE; i++) {
        VMTupleList cur = t[i];
        while (cur) {
            VMTupleList nxt = cur->next;
            free(cur);
            cur = nxt;
        }
        t[i] = NULL;
    }
}

/* ----------  clear_LR  (LicenseId, Relative)  ----------------- */
void clear_LR(LRHashTable table) {
    for (int i = 0; i < TABLE_SIZE; i++) {
        LRTupleList cur = table[i];
        while (cur) {
            LRTupleList nxt = cur->next;
            free(cur);
            cur = nxt;
        }
        table[i] = NULL;
    }
}

/* ----------  resetDatabases   --------------- */
void resetDatabases(LNACHashTable lnac,
                    VLHashTable   vl,
                    VDRHashTable  vdr,
                    VMHashTable   vm,
                    LRHashTable   lr)
{
    puts("Resetting the databases for the next part...");
    clear_LNAC(lnac);
    clear_VL(vl);
    clear_VDR(vdr);
    clear_VM(vm);
    clear_LR(lr);

    puts("Printing all databases after deleting all tuples...");
    printAll(lnac, vl, vdr, vm, lr);
    putchar('\n');

    puts("Reloading databases...");
    loadDatabases(lnac, vl, vdr, vm, lr);

    puts("Printing all databases after reloading...");
    printAll(lnac, vl, vdr, vm, lr);
}

/* ----------  printVLTupleList_selection  ---------------------- */
void printVLTupleList_selection(VLTupleList list) {
    puts("-------------------------------------------");
    printf("| %-15s |\n", "Vehicle");
    puts("-------------------------------------------");
    for (VLTupleList cur = list; cur; cur = cur->next) {
        printf("| %-15s |\n", cur->Vehicle);
    }
    puts("-------------------------------------------");
}

/* ----------  printVehicleTupleList_projection  ---------------- */
void printVehicleTupleList_projection(VehicleTupleList list) {
    puts("--------------");
    printf("| %-10s |\n", "Vehicle");
    puts("--------------");
    for (VehicleTupleList cur = list; cur; cur = cur->next) {
        printf("| %-10s |\n", cur->Vehicle);
    }
    puts("--------------");
}

/* ----------  printVDMTupleList  (join VM ▷◁ VDR results)  ------ */
void printVDMTupleList(VDMTupleList list) {
    puts("-------------------------------------------------------");
    printf("| %-10s | %-10s | %-15s |\n", "Vehicle", "Date", "Manufacturer");
    puts("-------------------------------------------------------");
    if (!list) {
        puts("  (no entries)");
    }
    for (VDMTupleList cur = list; cur; cur = cur->next) {
        printf("| %-10s | %-10s | %-15s |\n",
               cur->Vehicle, cur->Date, cur->Manufacturer);
    }
    puts("-------------------------------------------------------");
}

/* ----------  select_VDM_byManufacturer  (already defined)  --- */
/* 
    πDate,Result(σManufacturer=“Ford”(VM▷◁VDR))
   
*/
/* ===============================================================
   project_manufacturer  —  project only Manufacturer from VDMTupleList
 
   =============================================================== */
typedef struct ManufacturerTuple *ManufacturerTupleList;
struct ManufacturerTuple {
    char Manufacturer[15];
    ManufacturerTupleList next;
};

ManufacturerTupleList project_manufacturer(VDMTupleList joined_list) {
    ManufacturerTupleList mlist = NULL;
    for (VDMTupleList cur = joined_list; cur; cur = cur->next) {
        ManufacturerTupleList n = malloc(sizeof *n);
        strcpy(n->Manufacturer, cur->Manufacturer);
        n->next = mlist;
        mlist = n;
    }
    return mlist;
}

/* ===============================================================
   select_VDM_byDate  —  filter the joined VM▷◁VDR list by Date
   =============================================================== */
VDMTupleList select_VDM_byDate(VDMTupleList list, const char *date) {
    VDMTupleList sel = NULL;
    for (VDMTupleList cur = list; cur; cur = cur->next) {
        if (strcmp(cur->Date, date) == 0) {
            VDMTupleList n = malloc(sizeof *n);
            *n = *cur;
            n->next = sel;
            sel = n;
        }
    }
    return sel;
}
// Selection on VL by LicenseId: σLicenseId=id(VL)
VLTupleList select_VL_byLicenseId(VLHashTable t, int id) {
    VLTupleList res = NULL;
    for (int i = 0; i < TABLE_SIZE; i++) {
        for (VLTupleList c = t[i]; c; c = c->next) {
            if (c->LicenseId == id) {
                VLTupleList n = malloc(sizeof(*n));
                *n = *c;
                n->next = res;
                res = n;
            }
        }
    }
    return res;
}

// Projection of Vehicle attribute: πVehicle(VL)
VehicleTupleList project_Vehicle_fromVL(VLTupleList list) {
    VehicleTupleList res = NULL;
    for (VLTupleList c = list; c; c = c->next) {
        VehicleTupleList n = malloc(sizeof(*n));
        strcpy(n->Vehicle, c->Vehicle);
        n->next = res;
        res = n;
    }
    return res;
}

// Join VM ▷◁ VDR on Vehicle: combine Date and Manufacturer
VDMTupleList join_VM_VDR(VMHashTable vm, VDRHashTable vdr) {
    VDMTupleList res = NULL;
    for (int i = 0; i < TABLE_SIZE; i++) {
        for (VDRTupleList vr = vdr[i]; vr; vr = vr->next) {
            unsigned long h = hash_function(vr->Vehicle);
            for (VMTupleList m = vm[h]; m; m = m->next) {
                if (strcmp(vr->Vehicle, m->Vehicle) == 0) {
                    VDMTupleList n = malloc(sizeof(*n));
                    strcpy(n->Vehicle, vr->Vehicle);
                    strcpy(n->Date,    vr->Date);
                    strcpy(n->Manufacturer, m->Manufacturer);
                    n->next = res;
                    res = n;
                }
            }
        }
    }
    return res;
}

// Selection on join result by Manufacturer: σManufacturer=manu(VM▷◁VDR)
VDMTupleList select_VDM_byManufacturer(VDMTupleList list, const char *manu) {
    VDMTupleList res = NULL;
    for (VDMTupleList cur = list; cur; cur = cur->next) {
        if (strcmp(cur->Manufacturer, manu) == 0) {
            VDMTupleList n = malloc(sizeof(*n));
            *n = *cur;
            n->next = res;
            res = n;
        }
    }
    return res;
}


/* ===============================================================
   findManufacturersForDate  —  vehicle analogue of findSponsorsForDate
   =============================================================== */
ManufacturerTupleList findManufacturersForDate(VDRHashTable vdr_table,
                                               VMHashTable  vm_table,
                                               const char  *date) 
{
    // 1. join VM and VDR on Vehicle
    VDMTupleList joined = join_VM_VDR(vm_table, vdr_table);

    // 2. select only those entries matching the given date
    VDMTupleList dated  = select_VDM_byDate(joined, date);

    // 3. project only the Manufacturer attribute
    ManufacturerTupleList mlist = project_manufacturer(dated);

    return mlist;
}
